// ============================================
// AlpinTools — Serveur Node.js + Stripe
// © 2025 AlpinTools · Sallanches, Haute-Savoie
// ============================================
//
// INSTALLATION :
//   npm install express stripe
//   node server.js
//
// Puis ouvrez http://localhost:3000

const express = require('express');
const stripe  = require('stripe')('sk_test_REMPLACEZ_PAR_VOTRE_CLE_SECRETE');
const app     = express();

app.use(express.json());
app.use(express.static(__dirname)); // sert index.html, style.css, script.js

// ── Créer une session de paiement Stripe ──────────────────────────────────────
app.post('/create-checkout-session', async (req, res) => {
  const { priceId } = req.body;

  try {
    const session = await stripe.checkout.sessions.create({
      mode: 'subscription',
      payment_method_types: ['card'],
      line_items: [{ price: priceId, quantity: 1 }],
      success_url: 'http://localhost:3000?payment=success',
      cancel_url:  'http://localhost:3000/#tarifs',
      // Remplacez par votre vrai domaine en production :
      // success_url: 'https://alpintools.netlify.app?payment=success',
      // cancel_url:  'https://alpintools.netlify.app/#tarifs',
    });

    res.json({ sessionId: session.id });
  } catch (err) {
    console.error('Erreur Stripe :', err.message);
    res.status(500).json({ error: err.message });
  }
});

// ── Webhook Stripe (optionnel — pour confirmer les paiements côté serveur) ────
app.post('/webhook', express.raw({ type: 'application/json' }), (req, res) => {
  const sig     = req.headers['stripe-signature'];
  const secret  = 'whsec_VOTRE_WEBHOOK_SECRET'; // à récupérer dans le dashboard Stripe

  let event;
  try {
    event = stripe.webhooks.constructEvent(req.body, sig, secret);
  } catch (err) {
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  switch (event.type) {
    case 'checkout.session.completed':
      console.log('✅ Paiement réussi :', event.data.object.customer_email);
      // TODO : activer l'abonnement en base de données
      break;
    case 'customer.subscription.deleted':
      console.log('❌ Abonnement annulé');
      // TODO : désactiver l'accès Pro en base de données
      break;
    default:
      console.log(`Événement non géré : ${event.type}`);
  }

  res.json({ received: true });
});

// ── Démarrage du serveur ──────────────────────────────────────────────────────
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`\n🏔  AlpinTools tourne sur http://localhost:${PORT}\n`);
});
