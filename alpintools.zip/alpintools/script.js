/* ============================================
   AlpinTools — JavaScript principal
   © 2025 AlpinTools · Sallanches, Haute-Savoie
   ============================================ */

/* --- MODAL --- */
function openModal(type) {
  document.getElementById('modal-success').style.display = 'none';
  document.getElementById('modal-content').style.display = 'block';

  const titles = {
    signup:  ['CRÉER UN COMPTE',   'Accédez gratuitement à la météo alpine, au planificateur et au bilan carbone.'],
    pro:     ['PASSER EN PRO',     'Débloquez les conditions neige en temps réel et l\'export GPX illimité pour 9€/mois.'],
    expert:  ['PLAN EXPERT',       'Accédez aux alertes push, à l\'API et au badge Expert Montagne pour 19€/mois.'],
    sponsor: ['DEVENIR PARTENAIRE','Touchez nos 2 400+ utilisateurs passionnés d\'outdoor autour du Mont-Blanc.']
  };

  document.getElementById('modal-title').textContent = titles[type][0];
  document.getElementById('modal-desc').textContent  = titles[type][1];

  const showPass = ['signup', 'pro', 'expert'].includes(type);
  document.getElementById('pass-field').style.display = showPass ? 'block' : 'none';

  document.getElementById('modal').classList.add('open');
}

function closeModal() {
  document.getElementById('modal').classList.remove('open');
}

function submitModal() {
  document.getElementById('modal-content').style.display = 'none';
  document.getElementById('modal-success').style.display  = 'block';
  setTimeout(closeModal, 3000);
}

/* --- OUTIL CO2 --- */
function setCO2(btn, label, value, vs) {
  document.querySelectorAll('.co2-opt').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  const val = value.split(' ')[0];
  document.getElementById('co2-val').textContent = val;
  document.getElementById('co2-vs').textContent  = vs;
}

/* --- SMOOTH SCROLL --- */
document.querySelectorAll('a[href^="#"]').forEach(a => {
  a.addEventListener('click', e => {
    const target = document.querySelector(a.getAttribute('href'));
    if (target) {
      e.preventDefault();
      target.scrollIntoView({ behavior: 'smooth' });
    }
  });
});

/* --- ANIMATION BARRES AU SCROLL --- */
const observer = new IntersectionObserver(entries => {
  entries.forEach(e => {
    if (e.isIntersecting) e.target.style.animationPlayState = 'running';
  });
}, { threshold: 0.3 });

document.querySelectorAll('.rev-bar').forEach(b => {
  b.style.animationPlayState = 'paused';
  observer.observe(b);
});

/* --- FERMER MODAL EN CLIQUANT DEHORS --- */
document.getElementById('modal').addEventListener('click', function(e) {
  if (e.target === this) closeModal();
});

/* ============================================
   STRIPE — À configurer pour la production
   ============================================
   Pour activer les paiements réels :

   1. Remplacez 'pk_test_VOTRE_CLE' par votre clé publique Stripe
   2. Remplacez les priceId par vos vrais Price ID Stripe
   3. Mettez en place le serveur Node.js (voir server.js)

const stripe = Stripe('pk_test_VOTRE_CLE_PUBLIQUE');

async function subscribePro() {
  const response = await fetch('/create-checkout-session', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ priceId: 'price_PRO_ID' })
  });
  const { sessionId } = await response.json();
  stripe.redirectToCheckout({ sessionId });
}

async function subscribeExpert() {
  const response = await fetch('/create-checkout-session', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ priceId: 'price_EXPERT_ID' })
  });
  const { sessionId } = await response.json();
  stripe.redirectToCheckout({ sessionId });
}
============================================ */
