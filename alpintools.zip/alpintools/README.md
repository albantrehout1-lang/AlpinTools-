# 🏔 AlpinTools

> SaaS outdoor pour le massif du Mont-Blanc — Sallanches, Haute-Savoie

## Structure du projet

```
alpintools/
├── index.html    ← Page principale (HTML pur)
├── style.css     ← Tous les styles
├── script.js     ← Toute la logique JS + config Stripe
├── server.js     ← Serveur Node.js pour les paiements Stripe
└── README.md     ← Ce fichier
```

## Déploiement rapide (sans paiement)

1. Glissez-déposez le dossier sur [netlify.com](https://netlify.com)
2. Votre site est en ligne en 2 minutes ✅
3. Utilisez cette URL pour Stripe

## Activer les paiements Stripe

### 1. Installer les dépendances
```bash
npm install express stripe
```

### 2. Configurer vos clés
Dans `server.js`, remplacez :
- `sk_test_REMPLACEZ_PAR_VOTRE_CLE_SECRETE` → votre clé secrète Stripe

Dans `script.js`, décommentez le bloc Stripe et remplacez :
- `pk_test_VOTRE_CLE_PUBLIQUE` → votre clé publique Stripe
- `price_PRO_ID` → le Price ID de votre plan Pro (9€)
- `price_EXPERT_ID` → le Price ID de votre plan Expert (19€)

### 3. Lancer le serveur
```bash
node server.js
# → http://localhost:3000
```

### 4. Tester un paiement
Carte de test Stripe : `4242 4242 4242 4242`
Date : n'importe quelle date future · CVC : n'importe quoi

## Revenus estimés

| Utilisateurs | Revenu mensuel estimé |
|---|---|
| 500 | ~2 400 €/mois |
| 1 000 | ~4 850 €/mois |
| 2 500 | ~10 000 €/mois |

## Contact
Fait avec ❤️ pour la montagne — Sallanches, Haute-Savoie
